package com.atha.treemapindia;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TableRow.LayoutParams;

public class Attribute_Selection extends Activity{
	
	//private LinkedHashMap<String, String> hashmap = new LinkedHashMap<String, String>();
	private List<EditText> allEds = new ArrayList<EditText>();
	private List<Spinner> allSpinners = new ArrayList<Spinner>();
	private List<Spinner> allShowcase = new ArrayList<Spinner>();
	private List<EditText> allSize = new ArrayList<EditText>();
	private static ArrayList<Attribute> attributeList= new ArrayList<Attribute>();
	private static String object_Name =null;
	private String showcase;
	private DBHelper dbHelper;
	
	public static String getObject_Name() {
		return object_Name;
	}
	public static void setObject_Name(String object_Name) {
		Attribute_Selection.object_Name = object_Name;
	}
	
	
	public static ArrayList<Attribute> getAttributeList() {
		return attributeList;
	}
	public static void setAttributeList(ArrayList<Attribute> attributeList) {
		Attribute_Selection.attributeList = attributeList;
	}
	
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.attribute_selection);
	
		Button btnAddAttr = (Button)findViewById(R.id.add_Attr);
		btnAddAttr.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
            	createTableRow(v);

            } // end onClick
        }); // end setOnClickListener
		
		final EditText editText = (EditText) findViewById(R.id.editText1);
		
		dbHelper= new DBHelper(this);
		
		/*Button buttonLogin = (Button)findViewById(R.id.login);
		buttonLogin.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
            	//
            	setObject_Name(editText.getText().toString());
            	attributeList.removeAll(attributeList);
            	for(int i=0; i < allEds.size(); i++){
            	    //hashmap.put(allEds.get(i).getText().toString(),"INTEGER");
            		Attribute attribute = new Attribute();
            		attribute.setName(allEds.get(i).getText().toString());
            		attribute.setType(allSpinners.get(i).getSelectedItem().toString());
            		showcase=allShowcase.get(i).getSelectedItem().toString();
            		attribute.setShowcase(showcase);
            		
            		//temporarily size of list is stored in value
            		if(!showcase.equalsIgnoreCase("Button"))
            		{
            			attribute.setValue(allSize.get(i).getText().toString());
            		}
            		
            		attributeList.add(attribute); 		
            		
            	}
            	
        		 * PRISTART set for  table_name 
        		 
            	SQLiteDatabase db;
            	db=dbHelper.openDatabase();
            	//dbHelper.createBaseTables(db);
            	dbHelper.setNEW_TABLE(object_Name);
            	
        		dbHelper.insertintoMasterTable(getObject_Name(),getAttributeList() ,db);
        		dbHelper.create_new_table(getAttributeList(),db);
        		db.close();
            	
            	 * PRISTART call for upgrade DBHelper
            	 
            	//dbHelper=new DBHelper(getBaseContext());
        		// add object with attribute list to domain
            	
            	
            	
            	 * PRISTART directed to survey_form.class
            	 
            	
            	Intent mainIntent = new Intent(Attribute_Selection.this, LoginActivity.class);
				mainIntent.putExtra(DatabaseHelper.SURVEYOR_ID[0], 2);
				mainIntent.putExtra("attributeList", attributeList);
				mainIntent.putExtra("objectName", object_Name);
				startActivity(mainIntent);
				Attribute_Selection.this.finish();

            } // end onClick
        }); // end setOnClickListener	
		*/
		
		
		/*Button new_object = (Button)findViewById(R.id.new_object);
		new_object.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
    
            	Intent mainIntent = new Intent(Attribute_Selection.this, Attribute_Selection.class);
				mainIntent.putExtra(DatabaseHelper.SURVEYOR_ID[0], 2);
				startActivity(mainIntent);
				Attribute_Selection.this.finish();

            } // end onClick
        }); // end setOnClickListen
*/		
		
		
		Button buttonDomain = (Button)findViewById(R.id.next);
		buttonDomain.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
            	//
            	setObject_Name(editText.getText().toString());
            	attributeList.removeAll(attributeList);
            	for(int i=0; i < allEds.size(); i++){
            	    //hashmap.put(allEds.get(i).getText().toString(),"INTEGER");
            		Attribute attribute = new Attribute();
            		attribute.setName(allEds.get(i).getText().toString());
            		attribute.setType(allSpinners.get(i).getSelectedItem().toString());
            		showcase=allShowcase.get(i).getSelectedItem().toString();
            		attribute.setShowcase(showcase);
            		
            		//temporarily size of list is stored in value
            		if(!showcase.equalsIgnoreCase("Text"))
            		{
            			attribute.setValue(allSize.get(i).getText().toString());
            		}
            		
            		attributeList.add(attribute); 		
            		
            	}
            	/*
        		 * PRISTART set for  table_name 
        		 */
            	/*SQLiteDatabase db;
            	db=dbHelper.openDatabase();
            	//dbHelper.createBaseTables(db);
            	dbHelper.setNEW_TABLE(object_Name);
            	
        		dbHelper.insertintoMasterTable(getObject_Name(),getAttributeList() ,db);
        		dbHelper.create_new_table(getAttributeList(),db);
        		db.close();*/
            	
            	Intent mainIntent = new Intent(Attribute_Selection.this, Showcase_Selection.class);
				//mainIntent.putExtra(DatabaseHelper.SURVEYOR_ID[0], 2);
				/*mainIntent.putExtra("attributeList", attributeList);
				mainIntent.putExtra("objectName", object_Name);*/
				startActivity(mainIntent);
				Attribute_Selection.this.finish();

            } // end onClick
        }); // end setOnClickListener	


	}
	public void createTableRow(View v) {
		  //final Attribute attribute = new Attribute();
		  TableLayout tl = (TableLayout) findViewById(R.id.attrTableLayout);
		  TableRow tr = new TableRow(this);
		  LayoutParams lp = new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT);
		  tr.setLayoutParams(lp);

		  
		  EditText attName = new EditText(this);
		  attName.setLayoutParams(lp);
		  allEds.add(attName);
		  
		  //attribute.setName(attName.getText().toString());
		  
		  
		  Spinner attType =new Spinner(this);
		  attType.setLayoutParams(lp);
		  allSpinners.add(attType);
		  ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
			        R.array.selection_name , android.R.layout.simple_spinner_item);
		  adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		  attType.setAdapter(adapter);
		  
		  
		  Spinner attShowcase =new Spinner(this);
		  attShowcase.setLayoutParams(lp);
		  allShowcase.add(attShowcase);
		  ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(this,
			        R.array.showcase_name , android.R.layout.simple_spinner_item);
		  adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		  attShowcase.setAdapter(adapter1);

		  
		  EditText size = new EditText(this);
		  size.setLayoutParams(lp);
		  allSize.add(size);
		  
		  
          //attributeList.add(attribute);
		  tr.addView(attName);
		  tr.addView(attType);
		  tr.addView(attShowcase);
		  tr.addView(size);
		  //tr.addView(tvRight);
		  tl.addView(tr, new TableLayout.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));
		}
}
