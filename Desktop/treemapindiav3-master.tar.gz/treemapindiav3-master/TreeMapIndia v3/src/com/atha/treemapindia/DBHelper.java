package com.atha.treemapindia;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Iterator;
import java.util.LinkedHashMap;

import com.atha.csvexport.CSVWriter;

import android.R.bool;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;
import android.os.Environment;
import android.provider.Settings;
import android.util.Log;
import android.widget.Toast;

/**
 * This class handles all the database related things
 * */

public class DBHelper extends SQLiteOpenHelper
{
	public static final long	  SESSION_CHANGE_TIMEOUT	         = 10 * 60 * 1000;	                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                // 10

	public static final String	  DATABASE_NAME	                     = "MapIndia.db";

	public static int base_table_created;
	
	public static int getBase_table_created() {
		return base_table_created;
	}

	public static void setBase_table_created(int base_table_created) {
		DBHelper.base_table_created = base_table_created;
	}
	
	public static final String	  TABLE_ARRAY[]	                     = { "DATA_TABLE" };

	public static final String	  GID[]	                             = { "gid", "integer primary key autoincrement" };
	public static final String	  TABLE_PRABHAG_MASTER	             = "prabhag";
	public static final String	  TABLE_CLUSTER_MASTER	             = "cluster";
	public static final String	  TABLE_SURVEYOR	                 = "surveyor";
	public static final String	  TABLE_SESSION	                     = "session";
	/*PRISTART
	public static final String	  TABLE_TREE	                     = "Tree";
	public static final String	  TABLE_SPECIES_MASTER	             = "Species_list";
	public static final String	  TABLE_PROPERTY_MASTER	             = "property_types";
	public static final String	  TABLE_HEALTH_MASTER	             = "health_of_tree_master";
	public static final String	  TABLE_GROUND_MASTER	             = "ground_condition";
	public static final String	  TABLE_RISK_MASTER	                 = "risk_due_to_tree";
	public static final String	  TABLE_AREA_DETAILS	             = "area_details";
	public static final String	  TABLE_SESSION	                     = "session";
	PRIEND*/
	
	
	/*PRISTART
	public static final String	  GID[]	                             = { "gid", "integer primary key autoincrement" };
	public static final String	  PRABHAG_ID[]	                     = { "prabhagid", "integer" };
	public static final String	  OBJECT_ID[]	                     = { "objectid", "text" };
	public static final String	  CLUSTER_ID[]	                     = { "clusterid", "integer" };
	public static final String	  PROPERTY_ID[]	                     = { "propertyid", "text" };*/
	public static final String	  DEVICE_ID[]	                     = { "device_id", "text" };
	public static final String	  SURVEYOR_ID[]	                     = { "surveyor_id", "text" };
	public static final String	  SESSION_ID[]	                     = { "session_id", "text" };
	public static final String	  FORM_ID[]	                         = { "form_id", "text" };

	/*PRISTART
	public static final String	  PRABHAG_CITY_CODE[]	             = { "citycode", "integer" };
	public static final String	  PRABHAG_DESCRIPTION[]	             = { "description", "text" };
	public static final String	  PRABHAG_AREA[]	                 = { "area", "real" };
	public static final String	  PRABHAG_PERIMETER[]	             = { "perimeter", "real" };
	public static final String	  PRABHAG_SHAPE_LENGTH[]	         = { "shape_length", "real" };
	public static final String	  PRABHAG_SHAPE_AREA[]	             = { "shape_area", "real" };
	public static final String	  PRABHAG_GEOM[]	                 = { "geom", "text" };

	public static final String	  PRABHAG_COLUMN[][]	             = { GID, PRABHAG_ID, PRABHAG_CITY_CODE, OBJECT_ID, PRABHAG_DESCRIPTION, PRABHAG_AREA, PRABHAG_PERIMETER, PRABHAG_SHAPE_LENGTH, PRABHAG_SHAPE_AREA, PRABHAG_GEOM };


	public static final String	  CLUSTER_DESC[]	                 = { "description", "text" };
	public static final String	  CLUSTER_AREA[]	                 = { "area", "real" };
	public static final String	  CLUSTER_PERIMETER[]	             = { "perimeter", "real" };
	public static final String	  CLUSTER_SHAPE_LENGTH[]	         = { "shape_length", "real" };
	public static final String	  CLUSTER_SHAPE_AREA[]	             = { "shape_area", "real" };
	public static final String	  CLUSTER_GEOM[]	                 = { "geom", "text" };
	public static final String	  CLUSTER_LOCALITIES_NEIGHBOURHOOD[]	= { "localities_neighborhood", "text" };
	public static final String	  CLUSTER_COLUMN[][]	             = { GID, CLUSTER_ID, OBJECT_ID, PRABHAG_ID, CLUSTER_DESC, CLUSTER_AREA, CLUSTER_PERIMETER, CLUSTER_SHAPE_LENGTH, CLUSTER_SHAPE_AREA, CLUSTER_GEOM, CLUSTER_LOCALITIES_NEIGHBOURHOOD };*/

	public static final String	  SURVEYOR_AUTO_ID[]	             = { SURVEYOR_ID[0], "integer primary key autoincrement" };
	public static final String	  SURVEYOR_NAME[]	                 = { "surveyor_name", "text" };
	public static final String	  SURVEYOR_PASSWORD[]	             = { "password", "blob" };
	public static final String	  SURVEYOR_DOMAIN[]	             	 = { "domain", "text" };

	public static final String	  SURVEYOR_COLUMN[][]	             = { SURVEYOR_AUTO_ID, SURVEYOR_NAME, SURVEYOR_PASSWORD,SURVEYOR_DOMAIN };
	public  			String 	  NEW_TABLE							 = null;				
	public ArrayList<Attribute>   ATTRIBUTE_LIST					 = new ArrayList<Attribute>(); 
	/*PRISTART
	
	public static final String	  SESSION_TREES_SURVEYED[]	         = { "trees_surveyed", "integer" };
	PRIEND*/


	public static final String	  SESSION_OBJECT_SURVEYED[]	         = { "object_surveyed", "integer" };
	public static final String	  SESSION_TIME[]	                 = { "session_time", "integer" };

	public static final String	  SESSION_COLUMN[][]	             = { GID, SESSION_ID, SESSION_OBJECT_SURVEYED, SURVEYOR_ID, SESSION_TIME };
	

	

	

/*PRISTART
 	public static final String	  TABLE_ARRAY[]	                     = { TABLE_PRABHAG_MASTER, TABLE_TREE, TABLE_CLUSTER_MASTER, TABLE_SURVEYOR, TABLE_SPECIES_MASTER, TABLE_PROPERTY_MASTER, TABLE_HEALTH_MASTER, TABLE_GROUND_MASTER, TABLE_RISK_MASTER, TABLE_AREA_DETAILS, TABLE_SESSION };

	public static final String	  TABLE_COLUMN_ARRAY[][][]	         = { PRABHAG_COLUMN, TREE_COLUMN, CLUSTER_COLUMN, SURVEYOR_COLUMN, SPECIES_COLUMN, PROPERTY_COLUMN, HEALTH_COLUMN, GROUND_COLUMN, RISK_COLUMN, AREA_DETAILS_COLUMN, SESSION_COLUMN };
PRIEND*/
	
	/*
	 *  PRISTART create master table
	 */
	
	
	public static String	  PRABHAG_AREA[]	                 = { "area", "real" };
	public static String	  PRABHAG_PERIMETER[]	             = { "perimeter", "real" };
	public static String	  PRABHAG_SHAPE_LENGTH[]	         = { "shape_length", "real" };
	public static String	  PRABHAG_SHAPE_AREA[]	             = { "shape_area", "real" };
	public static String	  PRABHAG_GEOM[]	                 = { "geom", "text" };
	
	public static String 	  LAYER_NAME[] = {"LAYER_NAME","text"};
	public static String 	  LAYER_TYPE[] = {"LAYER_TYPE","text"};
	public static String 	  LAYER_COLUMN[][] = {LAYER_NAME,LAYER_TYPE};
	
	public static String 	  TABLE_NAME[] = {"TABLE_NAME","text primary key"};
	public static String   	  TABLE_ATTRIBUTE_TYPE[] = {"TABLE_ATTRIBUTE_TYPE","text"};
	public static String 	  MASTER_TABLE_COLUMN[][] = {TABLE_NAME,TABLE_ATTRIBUTE_TYPE};
	
	
	public static String 	  USER_ID[] = {"USER_ID","text"};
	public static String 	  SCREEN[] = {"SCREEN","text"};
	public static String 	  ATTRIBUTE[] = {"ATTRIBUTE","text"};
	public static String 	  VALUE[] = {"VALUE","text"};
	public static String 	  DOMAIN[] = {"DOMAIN","text"};
	public static String 	  LAYER_INFO[] = {"LAYER","text"};
	public static String 	  DATA_COLUMN[][] = {GID,USER_ID,SCREEN,ATTRIBUTE,VALUE,DOMAIN,LAYER_INFO};
	/*
	 * PRIEND 
	*/

	

	// PRISTART public static String	  TABLE_COLUMN_ARRAY[][][]	         = null;

	public static String	      DATABASE_PATH	                     = null;
	public static String getDATABASE_PATH() {
		return DATABASE_PATH;
	}

	public static void setDATABASE_PATH(String dATABASE_PATH) {
		DATABASE_PATH = dATABASE_PATH;
	}

	private static SQLiteDatabase	db;
	private Context	              context;
	private static String MASTER_TABLE_NAME;
	private static String LAYER_TABLE_NAME;
	public static String getLAYER_TABLE_NAME() {
		return LAYER_TABLE_NAME;
	}

	public static void setLAYER_TABLE_NAME(String lAYER_TABLE_NAME) {
		LAYER_TABLE_NAME = lAYER_TABLE_NAME;
	}

	public static String getMASTER_TABLE_NAME() {
		return MASTER_TABLE_NAME;
	}

	public static void setMASTER_TABLE_NAME(String mASTER_TABLE_NAME) {
		MASTER_TABLE_NAME = mASTER_TABLE_NAME;
	}

	
	/**
	 * Initialize the database
	 * */

	protected DBHelper(Context context, String name, CursorFactory factory, int version)
	{
		super(context, name, factory, version);
		this.context = context;
		setDATABASE_PATH(context.getDatabasePath(DATABASE_NAME).getPath());
		Log.i("r db", "refer db : " + DATABASE_PATH);
		openDatabase();
		//onCreate(db);
		
	}

	public DBHelper(Context context)
	{
		this(context, DATABASE_NAME, null, 1);
		 //db = getWritableDatabase();
		/*
		 * PRISTART
		 */
		/**/
	}
	
	/**
	 * call this method whenever an activity reloads or restarts, in order for it to call the database methods
	 */

	public SQLiteDatabase openDatabase()
	{
		close();
		try
		{
			db = SQLiteDatabase.openOrCreateDatabase(getDATABASE_PATH(), null);
		}
		catch (SQLiteException e)
		{
			 db = getWritableDatabase();
		}
		/*
		 * PRISTART
		 * return (db != null);
		 */
		return (db);
	}

	public void close()
	{
		if (db != null)
		{
			db.close();
			super.close();
		}
	}

	
	/*
	 * ser new table name
	 */
	
	public  String getNEW_TABLE() {
		return NEW_TABLE;
	}

	public  void setNEW_TABLE(String nEW_TABLE) {
		NEW_TABLE = nEW_TABLE;
	}

	
	/*
	 * set attributes/columns
	 */
	/*PRISTART
	  public static String[][][] getTABLE_COLUMN_ARRAY() {
		return TABLE_COLUMN_ARRAY;
	}*/

	/*PRISTART
	 public static void setTABLE_COLUMN_ARRAY(String[][][] tABLE_COLUMN_ARRAY) {
	 
		TABLE_COLUMN_ARRAY = tABLE_COLUMN_ARRAY;
	}*/


	public ArrayList<String> getAllUserNames()
	{
		Cursor cursor = db.query(TABLE_SURVEYOR, new String[] { SURVEYOR_NAME[0] }, null, null, null, null, null);
		ArrayList<String> names = new ArrayList<String>();
		for (; cursor.moveToNext();)
		{
			names.add(cursor.getString(0));
		}
		return names;
	}
	/*PRISTART
	  public Cursor getAllTreedetailCursor()
	{
		return db.query(TABLE_SPECIES_MASTER, new String[] { GID[0], SPECIES_LOCAL_NAME[0], SPECIES_SCIENTIFIC_NAME[0] }, null, null, null, null, null);
	}
	  
	
	

	public ArrayList<String> getAllPrabhagNumbers()
	{
		Cursor cursor = db.query(TABLE_PRABHAG_MASTER, new String[] { PRABHAG_ID[0] }, null, null, null, null, null);
		ArrayList<String> prabhagNumbers = new ArrayList<String>();
		for (; cursor.moveToNext();)
		{
			prabhagNumbers.add(cursor.getString(0));
		}
		return prabhagNumbers;
	}

	public String[] getPropertyTypes()
	{
		Cursor cursor = db.query(TABLE_PROPERTY_MASTER, new String[] { PROPERTY_TYPE[0] }, null, null, null, null, null);
		String str[] = new String[cursor.getCount()];
		for (int i = 0; cursor.moveToNext(); i++)
		{
			str[i] = cursor.getString(0);
		}
		return str;
	}

	public ArrayList<String> getClusterNumberAccordingToPrabhagNumber(String prabhagId)
	{
		Cursor cursor = db.query(TABLE_CLUSTER_MASTER, new String[] { CLUSTER_ID[0] }, PRABHAG_ID[0] + "=?", new String[] { prabhagId }, null, null, null);
		// cursor = db.rawQuery("select " + CLUSTER_ID[0] + " from " + TABLE_CLUSTER_MASTER +
		// " where " + PRABHAG_ID[0] + "=" + prabhagId, null);
		Log.i("database", "cluster cursor count : " + cursor.getCount());
		ArrayList<String> clusterNumbers = new ArrayList<String>();
		for (; cursor.moveToNext();)
		{

			clusterNumbers.add(cursor.getString(0));
		}
		return clusterNumbers;
	}

	public ArrayList<String> getAllClusterNumbers()
	{
		Cursor cursor = db.query(TABLE_CLUSTER_MASTER, new String[] { CLUSTER_ID[0] }, null, null, null, null, null);
		ArrayList<String> clusterNumbers = new ArrayList<String>();
		for (; cursor.moveToNext();)
		{
			clusterNumbers.add(cursor.getString(0));
		}
		return clusterNumbers;
	}

	public String[] getHealthOfTreeCursor()
	{
		Cursor cur = db.rawQuery("SELECT " + HEALTH_OF_TREE[0] + " FROM " + TABLE_HEALTH_MASTER, null);
		String str[] = new String[cur.getCount()];
		if (cur.getCount() > 0)
		{
			for (int i = 0; cur.moveToNext(); i++)
			{
				str[i] = cur.getString(0);
			}
		}
		return str;
	}

	public String[] getGroundTypeCursor()
	{
		Cursor cur = db.rawQuery("SELECT " + GROUND_TYPE[0] + " FROM " + TABLE_GROUND_MASTER, null);
		String str[] = new String[cur.getCount()];
		for (int i = 0; cur.moveToNext(); i++)
		{
			str[i] = cur.getString(0);
		}
		return str;
	}

	public String[] getRiskDueToTreeCursor()
	{
		Cursor cur = db.rawQuery("SELECT " + RISK_DUE_TO_TREE[0] + " FROM " + TABLE_RISK_MASTER, null);
		String str[] = new String[cur.getCount()];
		for (int i = 0; cur.moveToNext(); i++)
		{
			str[i] = cur.getString(0);
		}
		return str;
	}
	PRIEND*/

	public void createBaseTables(SQLiteDatabase db)
	{
		//db=openDatabase();
		String temp=getLAYER_TABLE_NAME();
		//db.execSQL(CREATE_TABLE_MASTER);
		//db.execSQL(CREATE_TABLE_LAYER);
		try{
		db.execSQL("DROP TABLE IF EXISTS " + getLAYER_TABLE_NAME());
		db.execSQL("DROP TABLE IF EXISTS " + getMASTER_TABLE_NAME());
		db.execSQL(createSQLString(getLAYER_TABLE_NAME(), LAYER_COLUMN));
		db.execSQL(createSQLString(getMASTER_TABLE_NAME(), MASTER_TABLE_COLUMN));
		//setBase_table_created(1);
		}
		catch(SQLException sqlex){
			System.out.println("error while creating base tables");
		}
		
	}
		
	@Override
	public void onCreate(SQLiteDatabase db)
	{
		Log.i("database", "db path : " + db.getPath());
		
		/*
		 * PRISTART create master table containing all tables name as id
		 */
		
		db.execSQL(createSQLString(TABLE_SURVEYOR, SURVEYOR_COLUMN));
		
		for (int i = 1; i <= 5; i++)
		{
			db.execSQL("insert into " + TABLE_SURVEYOR + "(" + SURVEYOR_COLUMN[1][0] + "," + SURVEYOR_COLUMN[2][0] + "," + SURVEYOR_COLUMN[3][0] + ") values('tree" + i + "','tree" + i + "','Tree')");
			db.execSQL("insert into " + TABLE_SURVEYOR + "(" + SURVEYOR_COLUMN[1][0] + "," + SURVEYOR_COLUMN[2][0] + "," + SURVEYOR_COLUMN[3][0] + ") values('school" + i + "','school" + i + "','School')");
		}
		
		try{
			db.execSQL(createSQLString("DATA_TABLE", DATA_COLUMN));
			//db.execSQL(createSQLString(getMASTER_TABLE_NAME(), MASTER_TABLE_COLUMN));
			
			}
			catch(SQLException sqlex){
				System.out.println("error while creating data table");
			}
		/*PRISTART
		 * 
		 for (int i = 0; i < TABLE_ARRAY.length; i++)
		{
			String sql = createSQLString(TABLE_ARRAY[i], TABLE_COLUMN_ARRAY[i]);
			Log.v("sql onCreate", sql);
			db.execSQL(sql);
		}
		
		for (int i = 1; i <= 10; i++)
		{
			db.execSQL("insert into " + TABLE_PRABHAG_MASTER + "(" + PRABHAG_ID[0] + ") values(" + i + ")");
			for (int j = 1; j <= 5; j++)
			{
				db.execSQL("insert into " + TABLE_CLUSTER_MASTER + "(" + CLUSTER_ID[0] + "," + PRABHAG_ID[0] + ") values(" + i + j + "," + i + ")");
			}
		}
		
		PRIEND*/
		
		/*PRISTART
		db.execSQL("insert into " + TABLE_PROPERTY_MASTER + "(" + PROPERTY_TYPE[0] + ") values('divider')");
		db.execSQL("insert into " + TABLE_PROPERTY_MASTER + "(" + PROPERTY_TYPE[0] + ") values('pavement')");
		db.execSQL("insert into " + TABLE_PROPERTY_MASTER + "(" + PROPERTY_TYPE[0] + ") values('apartments')");
		db.execSQL("insert into " + TABLE_PROPERTY_MASTER + "(" + PROPERTY_TYPE[0] + ") values('bunglow')");
		db.execSQL("insert into " + TABLE_PROPERTY_MASTER + "(" + PROPERTY_TYPE[0] + ") values('colony')");
		db.execSQL("insert into " + TABLE_PROPERTY_MASTER + "(" + PROPERTY_TYPE[0] + ") values('estate')");
		db.execSQL("insert into " + TABLE_PROPERTY_MASTER + "(" + PROPERTY_TYPE[0] + ") values('plot')");
		db.execSQL("insert into " + TABLE_PROPERTY_MASTER + "(" + PROPERTY_TYPE[0] + ") values('garden')");
		db.execSQL("insert into " + TABLE_PROPERTY_MASTER + "(" + PROPERTY_TYPE[0] + ") values('river bank')");
		db.execSQL("insert into " + TABLE_PROPERTY_MASTER + "(" + PROPERTY_TYPE[0] + ") values('pond side')");
		db.execSQL("insert into " + TABLE_PROPERTY_MASTER + "(" + PROPERTY_TYPE[0] + ") values('lake side')");


		db.execSQL("insert into " + TABLE_RISK_MASTER + "(" + RISK_DUE_TO_TREE[0] + ") values('growing against wall')");
		db.execSQL("insert into " + TABLE_RISK_MASTER + "(" + RISK_DUE_TO_TREE[0] + ") values('growing in drain')");
		db.execSQL("insert into " + TABLE_RISK_MASTER + "(" + RISK_DUE_TO_TREE[0] + ") values('none')");
		db.execSQL("insert into " + TABLE_RISK_MASTER + "(" + RISK_DUE_TO_TREE[0] + ") values('other')");
		
PRIEND*/
		}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
	{
		Log.v("upgrade db", "old version: " + oldVersion + " newVersion: " + newVersion);
		/*PRISTART
		 String[] str = getDropTableSQLString(TABLE_ARRAY);
		for (int i = 0; i < str.length; i++)
		{
			db.execSQL(str[i]);
		}
		PRIEND*/
		/*ATTRIBUTE_LIST=Attribute_Selection.getAttributeList();
		NEW_TABLE=Attribute_Selection.getObject_Name();
		StringBuilder createQuery = new StringBuilder();
		
		createQuery.append("CREATE TABLE IF NOT EXISTS " + NEW_TABLE + "( ");	
	            //+ KEY_ROWID + " INTEGER PRIMARY KEY AUTOINCREMENT )"
		Iterator<Attribute> it = ATTRIBUTE_LIST.iterator();
		Attribute tempattr = it.next();
		int index=0;
		while(it.hasNext()){
			if(index!=0)
				createQuery.append(" , ");
			index=1;
			createQuery.append( tempattr.getName() +" "+ tempattr.getType() );
		}
		createQuery.append(" ) ");
		db.execSQL(createQuery.toString());
		insertintoMasterTable(NEW_TABLE);*/
		/* PRISTART */
		  //onCreate(db);
		 
	}
	
	/*
	 * PRISTART sql query to create table
	 */
	public void create_new_table(ArrayList<Attribute> list, SQLiteDatabase db)
	{
		StringBuilder sql = new StringBuilder();
		int index=0;
		sql.append("CREATE TABLE "+ getNEW_TABLE()+" " + "(");
		Iterator<Attribute> it = list.iterator();
		Attribute attr =new Attribute();
		           while(it.hasNext())
		           {
		        	   attr =it.next();
		        	   if(index!=0)
		   				sql.append(" , ");
		   				index=1;
		        	   sql.append(" "+attr.getName()+" " + attr.getType());
		        	   
		           }
		           sql.append(" ) ");
		           db.execSQL(sql.toString());
	}
	
	
	public String[] getDropTableSQLString(String[] TABLE_ARRAY)
	{
		String str[] = new String[TABLE_ARRAY.length];
		StringBuilder sql = new StringBuilder();
		for (int i = 0; i < TABLE_ARRAY.length; i++)
		{
			sql.append("DROP TABLE IF EXISTS " + TABLE_ARRAY[i] + ";");
			Log.v("upgrade sql", sql.toString());
			str[i] = sql.toString();
			sql = new StringBuilder();
		}
		return str;
	}

	public String createSQLString(String name, String[][] KEY)
	{
		StringBuilder sql = new StringBuilder();
		sql.append("CREATE TABLE " + name + " (");
		Log.v("", "KEY.length=" + KEY.length);
		for (int i = 0; i < KEY.length; i++)
		{
			Log.v("", "KEY[" + i + "].length=" + KEY[i].length);
			sql.append((i == 0 ? "" : ","));
			for (int j = 0; j < KEY[i].length; j++)
			{
				sql.append((j == 0 ? "" : " ") + KEY[i][j]);
			}
		}
		sql.append(");");
		return sql.toString();
	}
	
	
	
	/*
	 * PRISTART enter into master table entry for new table_name 
	 */
	public void insertintoMasterTable(String tableName, ArrayList<Attribute> attrList, SQLiteDatabase db)
	{
		//SQLiteDatabase db = this.getWritableDatabase();
		 
        ContentValues values = new ContentValues();
        values.put("TABLE_NAME", tableName);
        StringBuilder att=new StringBuilder();
        Iterator<Attribute> it = attrList.iterator();
        int count=0;
        String name,type,showcase,range,value;
        /*while(it.hasNext())
        {
        	Attribute attribute =it.next();
        	if(count!=0)
        		att.concat(" ");
        	count=1;
        	att.concat(attribute.getName().toString()+"_"+attribute.getType().toString());
        
        }*/
        for (Attribute attribute : attrList)
        {
        	if(count!=0)
    		{
    			att.append(",");
    		}
        	
        	name=attribute.getName();
        	type=attribute.getType();
        	showcase=attribute.getShowcase();
        	if(showcase.equalsIgnoreCase("text"))
        	{
        		range=attribute.getRange();
        		value=null;
        	}
        	else
        	{
        		range=attribute.getRange();
        		value=attribute.getValue();
        	}
        	//if(count==0)
        	//{	
        		//att=name;
        		//att.concat(type);
        	//}	
        	//else
        	//{
        		
        	count=1;
        	String temp=name+":"+type+":"+showcase+":"+range+":"+value;
        	att.append(temp);
        	//}
        	String attr=att.toString();
        	System.out.println(attr);
        }
        values.put("TABLE_ATTRIBUTE_TYPE", att.toString());
        db.insert(getMASTER_TABLE_NAME(), null, values);
		//db.execSQL("insert into " + " MASTER_TABLE " + "( TABLE_NAME ) values(" + tableName +")");
	}
	
	public static void insertintoLayerTable(ArrayList<Attribute> layerList)
	{
		//SQLiteDatabase db = this.getWritableDatabase();
		 
        ContentValues values = new ContentValues();
        Iterator<Attribute> it= layerList.iterator();
        Attribute tempattr= new Attribute();;
        while(it.hasNext()){
        	//tempattr 
        	tempattr = it.next();
        values.put("LAYER_NAME", tempattr.getName());
        values.put("LAYER_TYPE", tempattr.getType());
        db.insert(getLAYER_TABLE_NAME(), null, values);
        //values.put("LAYER_VALUE", tempattr.getValue());
        }
        //db.insert(getLAYER_TABLE_NAME(), null, values);
		//db.execSQL("insert into " + " MASTER_TABLE " + "( TABLE_NAME ) values(" + tableName +")");
	}
	
	public static void insertintoDataTable(String id,String screen,String domain,String attributeName,String value,SQLiteDatabase db)
	{
		ContentValues values = new ContentValues();
		values.put("USER_ID", id);
        values.put("SCREEN", screen);
        values.put("ATTRIBUTE", attributeName);
        values.put("VALUE", value);
        values.put("DOMAIN", domain);
        db.insert( "DATA_TABLE", null, values);
	}
	
	public void addRowToTable(ArrayList<Attribute> arrayList)
	{
		Iterator<Attribute> it = arrayList.iterator();
		Attribute tempattr = new Attribute();
		ContentValues values = new ContentValues();
		while(it.hasNext())
		{
			tempattr =it.next();
	        values.put(tempattr.getName(), tempattr.getValue());
	        
		}
		db.insert(getMASTER_TABLE_NAME(), null, values);
	}
	
	public long getNoOfRowsInTable(SQLiteDatabase db, String table)
	{
		String sql = "SELECT COUNT(*) FROM " + table;
	    SQLiteStatement statement = db.compileStatement(sql);
	    long count = statement.simpleQueryForLong();
	    return count;
	}
	
	 public int authenticateUser(String name, String passwd)
	{
		 
		Cursor surveyorCursor = db.query(TABLE_SURVEYOR, new String[] { SURVEYOR_ID[0], SURVEYOR_NAME[0], SURVEYOR_PASSWORD[0] }, SURVEYOR_NAME[0] + "=? and " + SURVEYOR_PASSWORD[0] + "=?", new String[] { name, passwd }, null, null, null);
		Log.i("authenticate", "cursor rows: " + surveyorCursor.getCount());
		if(name.equals("admin") && passwd.equals("admin"))
			return -1;
		else if (surveyorCursor.getCount() > 0)
		{
			surveyorCursor.moveToNext();
			return surveyorCursor.getInt(0);
		}
		return 0;
	}

	 
	 public String getUserDomain(String name,SQLiteDatabase db)
		{
		 String col_name;
		 String domain=null;

			Cursor cursor = db.query(TABLE_SURVEYOR, new String[] { SURVEYOR_AUTO_ID[0], SURVEYOR_NAME[0], SURVEYOR_PASSWORD[0],SURVEYOR_DOMAIN[0]}, SURVEYOR_NAME[0] + "=?", new String[] { name}, null, null, null);
			if(cursor.getCount() > 0)
			{
				
				cursor.moveToNext();
				domain=cursor.getString(3);
				
			/*int i = cursor.getColumnCount();
			System.out.println(i);*/
			}
					 	 	
			return domain;
		}
	 
	 public ArrayList<Screens> getScreensForUser(String name,SQLiteDatabase db )
		{
		 	Screens screen;
		 	String screenName=null;
		 	String attributes=null;
		 	String domain=getUserDomain(name,db);
		 	ArrayList<Screens> screenList=new ArrayList<Screens>();
		 	Cursor  cursor = db.rawQuery("select * from " + ("MASTER_").concat(domain),null);
		 	int index=1;
		 	if (cursor.moveToFirst()) {

	            while (cursor.isAfterLast() == false) {
	               //noOfScreens++;
	            	screen=new Screens();
	            	screenName = cursor.getString(cursor.getColumnIndex("TABLE_NAME"));
	            	attributes = cursor.getString(cursor.getColumnIndex("TABLE_ATTRIBUTE_TYPE"));
	            	screen.setIndex(index);
	            	screen.setName(screenName);
	            	screen.setAttributes(getAttributesFromString(attributes));
	            	screenList.add(screen);
	            	index++;
	                cursor.moveToNext();
	                
	            }
	        }
			
			return screenList;
		}
	 	
	 public ArrayList<Attribute> getAttributesFromString(String attrString)
	 {
		 	ArrayList<Attribute> attributes=new ArrayList<Attribute>();
		 	String attrArray[]=null;
            int size;
            int index=0;
            Attribute attr;
            String[] attrValues;
            if(attrString.contains(",")){
            	attrArray=attrString.split(",");
            	size=attrArray.length;
            
            	while(size!=0)
            	{
            	
            			attr= new Attribute();
            			attrValues=attrArray[index].split(":");
            			index++;
            			attr.setName(attrValues[0]);
            			attr.setType(attrValues[1]);
            			attr.setShowcase(attrValues[2]);
            			attr.setRange(attrValues[3]);
               			attr.setValue(attrValues[4]);
            			attributes.add(attr);
            			size--;
            	}
            }
        	else
    		{
        		attr= new Attribute();
    			attrValues=attrString.split(":");
    			attr.setName(attrValues[0]);
    			attr.setType(attrValues[1]);
    			attr.setShowcase(attrValues[2]);
    			attr.setRange(attrValues[3]);
    			attr.setValue(attrValues[4]);
    			attributes.add(attr);
    		}
		 	return attributes;
	 }
	/*PRISTART
	  public long insertAreadetails(Area_Details _ad)
	{
		ContentValues newArea = new ContentValues();

		// Assign value for each row

		newArea.put(AREA_DETAILS_PROPERTY_TYPE[0], _ad.get_prop_type());
		newArea.put(AREA_DETAILS_PROPERTY_OWNER[0], _ad.get_prop_owner());
		newArea.put(AREA_DETAILS_HOUSE_NUMBER[0], _ad.get_house_no());
		newArea.put(AREA_DETAILS_SURVEY_NUMBER[0], _ad.get_survey());
		newArea.put(AREA_DETAILS_PROPERTY_DESC[0], _ad.get_prop_desc());
		newArea.put(AREA_DETAILS_PROPERTY_AREA[0], _ad.get_prop_area());
		newArea.put(FORM_ID[0], _ad.get_form_key());

		// Insert the row.
		long gid = db.insert(TABLE_AREA_DETAILS, null, newArea);
		Cursor cur = db.rawQuery("SELECT " + DatabaseHelper.GID[0] + " from " + DatabaseHelper.TABLE_AREA_DETAILS + " WHERE " + DatabaseHelper.GID[0] + "=" + gid, null);
		if (cur.getCount() > 0)
		{
			// Toast.makeText(context, "Values inserted", Toast.LENGTH_LONG).show();
		}
		return gid;
	}

	public long insertSurveydetails(TreeDetails _sd)
	{
		// Create a new row of values to insert.
		ContentValues newSurveyValues = new ContentValues();
		// Assign values for each row.
		String androidId = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);

		newSurveyValues.put(FORM_ID[0], _sd.getFormNumber());
		newSurveyValues.put(PROPERTY_ID[0], _sd.getPropertyId());
		
		// Insert the row.
		return db.insert(TABLE_TREE, null, newSurveyValues);
	}
PRIEND*/
	
	/*PRISTART
	  public Cursor getTreeSurveyDump()
	{
		return db.rawQuery("SELECT * FROM " + TABLE_TREE + " WHERE " + TREE_DELETED[0] + "=0", null);
	}

	public Cursor getSessionDump()
	{
		return db.rawQuery("SELECT * FROM " + TABLE_SESSION, null);
	}
PRIEND*/
	
	// public long createNewSession()
	// {
	// long sessionId = 0;
	// Cursor cursor = db.rawQuery("SELECT " + SESSION_ID[0] + " FROM " + TABLE_SESSION, null);
	// if (cursor.getCount() == 0)
	// {
	// sessionId = 1;
	// }
	// else
	// {
	// cursor.moveToLast();
	// sessionId = cursor.getInt(0);
	// sessionId++;
	// }
	// ContentValues values = new ContentValues();
	// values.put(SESSION_ID[0], sessionId);
	// values.put(SESSION_TREES_SURVEYED[0], 0);
	// values.put(SESSION_TIME[0], System.currentTimeMillis());
	// long res = db.insert(TABLE_SESSION, null, values);
	// return (res == 1 ? sessionId : 0);
	// }

	public String createSession(String sessionId, int surveyorId)
	{
		System.out.println("Creating new session with sessionId: " + sessionId);
		ContentValues values = new ContentValues();
		values.put(SESSION_ID[0], sessionId);
		 values.put(SESSION_OBJECT_SURVEYED[0], 0);
		 
		values.put(SURVEYOR_ID[0], surveyorId);
		values.put(SESSION_TIME[0], System.currentTimeMillis());

		db.insert(TABLE_SESSION, null, values);

		return sessionId;
	}
	
	/**
	 * return a new session if the current session is more than 10 mins old
	 * */

	/*PRISTART
	  public String getSessionAccordingTo10Mins(int surveyorId)
	{
		int ses;
		Cursor cursor = db.rawQuery("SELECT " + GID[0] + "," + SESSION_ID[0] + "," + SESSION_TREES_SURVEYED[0] + "," + SESSION_TIME[0] + "," + SURVEYOR_ID[0] + " FROM " + TABLE_SESSION + " WHERE " + SURVEYOR_ID[0] + "=" + surveyorId, null);
		Calendar cal = Calendar.getInstance();
		int day = cal.get(cal.DAY_OF_MONTH);
		String androidId = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
		String sessionId = androidId + "_" + day + "_" + surveyorId + "_";
		if (cursor.getCount() == 0)
		{
			ses = 1;
			sessionId += ses;
			return createSession(sessionId, surveyorId);
		}
		else
		{
			cursor.moveToLast();
			long time = cursor.getLong(3);
			long currTime = System.currentTimeMillis();
			ses = cursor.getInt(0);
			long result = currTime - time;
			Toast.makeText(context, "time lapse: " + (result / 60000) + " min(s)", Toast.LENGTH_LONG).show();
			if (result > SESSION_CHANGE_TIMEOUT)
			{
				if (cursor.getInt(2) > 0)
				{
					ses++;
					sessionId += ses;
					return createSession(sessionId, surveyorId);
				}
			}
			sessionId += ses;
		}
		return sessionId;
	}
	PRIEND*/
	
	/**
	 * update the time column of session,after creating a new session, so that it gives the correct session for 10 mins interval
	 * */

	/* PRISTART
	public boolean updateSessionTime(String sessionId, int surveyorId)
	{
		int treesSurveyed = 0;
		Cursor cursor = db.rawQuery("SELECT " + SESSION_TREES_SURVEYED[0] + " FROM " + TABLE_SESSION + " WHERE " + SESSION_ID[0] + "='" + sessionId + "' and " + SURVEYOR_ID[0] + "=" + surveyorId, null);
		Log.i("updatesession", "cursor size: " + cursor.getCount() + " session: " + sessionId);
		cursor.moveToNext();
		treesSurveyed = cursor.getInt(0);
		Log.i("update", "session id: " + sessionId + " tress surveyed: " + treesSurveyed);
		cursor.close();
		treesSurveyed++;
		ContentValues values = new ContentValues();
		values.put(SESSION_TIME[0], System.currentTimeMillis());
		values.put(SESSION_TREES_SURVEYED[0], treesSurveyed);
		int res = db.update(TABLE_SESSION, values, SESSION_ID[0] + "=?", new String[] { sessionId + "" });
		return (res == 1 ? true : false);
	}
	PRIEND*/
	
	public void databaseDump(String androidId) throws IOException
	{
		for (int i = 0; i < TABLE_ARRAY.length; i++)
		{
			File myNewFolder = new File(Environment.getExternalStorageDirectory().toString() + "/" + androidId + "/TreeCensus");
			myNewFolder.mkdirs();
			File myFile = new File(Environment.getExternalStorageDirectory().toString() + "/" + androidId + "/TreeCensus/" + TABLE_ARRAY[i] + ".csv");
			myFile.createNewFile();
			CSVWriter csvWrite = new CSVWriter(new FileWriter(myFile));
			Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_ARRAY[i], null);
			Log.i("data dump", "dumping data for " + TABLE_ARRAY[i]);
			csvWrite.writeNext(cursor.getColumnNames());
			Log.i("data dump", TABLE_ARRAY[i] + " columns: " + Arrays.toString(cursor.getColumnNames()));
			String arrStr[] = new String[cursor.getColumnCount()];
			while (cursor.moveToNext())
			{
				for (int j = 0; j < arrStr.length; j++)
				{
					arrStr[j] = cursor.getString(j);
				}
				Log.i("data dump", "data: " + Arrays.toString(arrStr));
				csvWrite.writeNext(arrStr);
			}
			csvWrite.close();
			cursor.close();
		}
	}

	 
	public Session[] getAllSessions()
	{
		Cursor sessionCursor = db.query(TABLE_SESSION, new String[] { GID[0], SESSION_ID[0], SESSION_OBJECT_SURVEYED[0], SESSION_TIME[0], SURVEYOR_ID[0] }, null, null, null, null, null);
		Session sessions[] = new Session[sessionCursor.getCount()];
		for (int i = 0; i < sessions.length; i++)
		{
			sessions[i] = new Session();
			sessionCursor.moveToNext();
			sessions[i].setGid(sessionCursor.getInt(0));
			sessions[i].setId(sessionCursor.getString(1));
			sessions[i].setNumTrees(sessionCursor.getInt(2));
			sessions[i].setTime(sessionCursor.getLong(3));
			sessions[i].setSurveyorId(sessionCursor.getInt(4));
			// sessions[i].setTrees(getTreeDetailsAccordingToSessionId(sessions[i].getId()));
		}
		return sessions;
	}

	
	  public Session[] getSessionsAccordingToSurveyorId(int surveyorId)
	 
	{
		Cursor sessionCursor = db.query(TABLE_SESSION, new String[] { GID[0], SESSION_ID[0], SESSION_OBJECT_SURVEYED[0], SESSION_TIME[0], SURVEYOR_ID[0] }, SURVEYOR_ID[0] + "=" + surveyorId, null, null, null, null);
		Session sessions[] = new Session[sessionCursor.getCount()];
		for (int i = 0; i < sessions.length; i++)
		{
			sessions[i] = new Session();
			sessionCursor.moveToNext();
			sessions[i].setGid(sessionCursor.getInt(0));
			sessions[i].setId(sessionCursor.getString(1));
			sessions[i].setNumTrees(sessionCursor.getInt(2));
			sessions[i].setTime(sessionCursor.getLong(3));
			sessions[i].setSurveyorId(sessionCursor.getInt(4));
			// sessions[i].setTrees(getTreeDetailsAccordingToSessionId(sessions[i].getId()));
		}
		return sessions;
	}

	/* PRISTART
	 public TreeDetails[] getTreeDetailsAccordingToSessionId(String sessionGid, int surveyorId)
	 
	{
		Cursor treeCursor = db.query(TABLE_TREE, new String[] { TREE_NUMBER[0], PRABHAG_ID[0], CLUSTER_ID[0], TREE_NAME[0], TREE_BOTANICAL_NAME[0], TREE_GIRTH_M[0], TREE_HEIGHT_M[0], TREE_NEST[0], TREE_BURROWS[0], TREE_FLOWERS[0], TREE_FRUITS[0], TREE_NAILS[0], TREE_POSTER[0], TREE_WIRES[0], TREE_GUARD[0], TREE_OTHER_NUISSANCE[0], TREE_OTHER_NUISSANCE_DESC[0], TREE_HEALTH_OF_TREE[0], TREE_GROUND_TYPE[0], TREE_GROUND_DESC[0], TREE_RISK_DUE_TO_TREE[0], TREE_RISK_DESC[0], TREE_REFER_TO_DEPT[0], TREE_SPECIAL_OTHER[0], TREE_SPECIAL_OTHER_DESC[0], TREE_LATTITUDE[0], TREE_LONGITUDE[0], TREE_POINT[0], TREE_CREATION_DATE[0], TREE_CREATION_TIME[0], DEVICE_ID[0], SURVEYOR_ID[0], SESSION_ID[0], TREE_PHOTO_F_1[0], TREE_PHOTO_F_2[0], TREE_PHOTO_P_1[0], TREE_PHOTO_P_2[0], TREE_PHOTO_OTHER[0], PROPERTY_ID[0], GID[0] }, SESSION_ID[0] + "=? and " + TREE_DELETED[0] + "=0 and " + TREE_EDIT_TRACE[0] + " like '0' and " + SURVEYOR_ID[0] + "=" + surveyorId, new String[] { sessionGid + "" }, null, null, null);
		TreeDetails trees[] = new TreeDetails[treeCursor.getCount()];
		for (int j = 0; j < trees.length; j++)
		{
			trees[j] = new TreeDetails();
			treeCursor.moveToNext();
			trees[j].setNumber(treeCursor.getInt(0));
			trees[j].setPrabhagId(treeCursor.getInt(1));
			trees[j].setClusterId(treeCursor.getInt(2));
			trees[j].setFormNumber(trees[j].getPrabhagId() + "_" + trees[j].getClusterId());
			trees[j].setName(treeCursor.getString(3));
			trees[j].setBotanicalName(treeCursor.getString(4));
			trees[j].setGirth(treeCursor.getDouble(5));
			trees[j].setHeight(treeCursor.getDouble(6));
			trees[j].setNest(treeCursor.getString(7).equals("1") ? true : false);
			trees[j].setBurrows(treeCursor.getString(8).equals("1") ? true : false);
			trees[j].setFlowers(treeCursor.getString(9).equals("1") ? true : false);
			trees[j].setFruits(treeCursor.getString(10).equals("1") ? true : false);
			trees[j].setNails(treeCursor.getString(11).equals("1") ? true : false);
			trees[j].setPoster(treeCursor.getString(12).equals("1") ? true : false);
			trees[j].setWires(treeCursor.getString(13).equals("1") ? true : false);
			trees[j].setTreeGuard(treeCursor.getString(14).equals("1") ? true : false);
			trees[j].setOtherNuissance(treeCursor.getString(15).equals("1") ? true : false);
			trees[j].setOtherNuissanceDesc(treeCursor.getString(16));
			trees[j].setHealth(treeCursor.getString(17));
			trees[j].setGroundType(treeCursor.getString(18));
			trees[j].setGroundDesc(treeCursor.getString(19));
			trees[j].setRiskDueToTree(treeCursor.getString(20));
			trees[j].setRiskDesc(treeCursor.getString(21));
			trees[j].setReferToDept(treeCursor.getString(22).equals("1") ? true : false);
			trees[j].setSpecialOther(treeCursor.getString(23).equals("1") ? true : false);
			trees[j].setSpecialOtherDesc(treeCursor.getString(24));
			trees[j].setLattitude(treeCursor.getDouble(25));
			trees[j].setLongitude(treeCursor.getDouble(26));
			trees[j].setPoint(treeCursor.getString(27));
			trees[j].setCreationDate(treeCursor.getString(28));
			trees[j].setCreationTime(treeCursor.getString(29));
			trees[j].setDeviceId(treeCursor.getString(30));
			trees[j].setSurveyorId(treeCursor.getInt(31));
			Cursor surveyorCursor = db.query(TABLE_SURVEYOR, new String[] { SURVEYOR_NAME[0] }, SURVEYOR_ID[0] + "=?", new String[] { treeCursor.getString(31) }, null, null, null);
			if (surveyorCursor.getCount() > 0)
			{
				surveyorCursor.moveToNext();
				trees[j].setSurveyorName(surveyorCursor.getString(0));
			}
			trees[j].setSessionId(treeCursor.getString(32));
			trees[j].setImageF1(treeCursor.getString(33));
			trees[j].setImageF2(treeCursor.getString(34));
			trees[j].setImageP1(treeCursor.getString(35));
			trees[j].setImageP2(treeCursor.getString(36));
			trees[j].setImageOther(treeCursor.getString(37));
			trees[j].setPropertyId(treeCursor.getString(38));
			Cursor propertyCursor = db.query(TABLE_AREA_DETAILS, new String[] { AREA_DETAILS_PROPERTY_TYPE[0] }, GID[0] + "=?", new String[] { treeCursor.getString(38) }, null, null, null);
			if (propertyCursor.getCount() > 0)
			{
				propertyCursor.moveToNext();
				trees[j].setPropertyType(propertyCursor.getString(0));
			}
			trees[j].setGid(treeCursor.getLong(39));
		}
		return trees;
	}*/

	/* PRISTART
	public void deleteTreeEntry(long treeGid)
	{
		ContentValues values = new ContentValues();
		values.put(TREE_DELETED[0], 1);
		// Cursor cursor = db.rawQuery("UPDATE " + TABLE_TREE + " SET " + TREE_DELETED[0] +
		// "=1 WHERE " + GID[0] + "=" + treeGid, null);
		int up = db.update(TABLE_TREE, values, GID[0] + "=" + treeGid, null);
		// Toast.makeText(context, "deleted: " + up, Toast.LENGTH_SHORT).show();
	}
	*/

	/* PRISTART
	public void updateTreeWithEditTrace(TreeDetails tree)
	{
		long gid = insertSurveydetails(tree);
		ContentValues values = new ContentValues();
		values.put(TREE_EDIT_TRACE[0], gid);
		db.update(TABLE_TREE, values, GID[0] + "=" + tree.getGid(), null);
	}
	*/
}
