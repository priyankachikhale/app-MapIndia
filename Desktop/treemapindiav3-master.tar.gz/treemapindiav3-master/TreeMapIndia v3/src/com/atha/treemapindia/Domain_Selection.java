package com.atha.treemapindia;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

public class Domain_Selection extends Activity{
	
	public static String selectedItem =null;
	//private DBHelper dbHelper;
	public static String getSelectedItem() {
		return selectedItem;
	}

	public static void setSelectedItem(String selectedItem) {
		Domain_Selection.selectedItem = selectedItem;
	}

	protected void onCreate(Bundle savedInstanceState)
	{
		
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.domain_selection);
		Spinner spinner = (Spinner) findViewById(R.id.spinner1);
		
		// Create an ArrayAdapter using the string array and a default spinner layout
		ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
		        R.array.domain_name , android.R.layout.simple_spinner_item);
		// Specify the layout to use when the list of choices appears
		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		// Apply the adapter to the spinner
		spinner.setAdapter(adapter);
		//
		
		spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
		
			public void onItemSelected(AdapterView<?> parent, View view,  int pos, long id)
			{

				String user=LoginActivity.getLogin();
				setSelectedItem(parent.getItemAtPosition(pos).toString());
				//dbHelper =new DBHelper();
				//
				//{
				/*DBHelper.setMASTER_TABLE_NAME(("MASTER_").concat(getSelectedItem()));
				DBHelper.setLAYER_TABLE_NAME(("LAYER").concat(getSelectedItem()));*/
				
				
				//}
				/*else
				{
				Intent mainIntent = new Intent(Domain_Selection.this, Layer_Selection.class);
				//mainIntent.putExtra(DatabaseHelper.SURVEYOR_ID[0], 2);
				startActivity(mainIntent);
				Domain_Selection.this.finish();
				}*/
				/*if (getSelectedItem().contains("Tree"))
				{
					//System.out.println("TREE");
					
					Intent mainIntent = new Intent(Domain_Selection.this, Layer_Selection.class);
					//mainIntent.putExtra(DatabaseHelper.SURVEYOR_ID[0], 2);
					startActivity(mainIntent);
					Domain_Selection.this.finish();
					
					//propertySelected = true;
				}*/
				if(!getSelectedItem().contains("NoSelection"))
				{
					if(user.equals("admin"))
					{
						DBHelper.setMASTER_TABLE_NAME(("MASTER_").concat(getSelectedItem()));
						DBHelper.setLAYER_TABLE_NAME(("LAYER_").concat(getSelectedItem()));
						Intent mainIntent = new Intent(Domain_Selection.this, Layer_Selection.class);
						startActivity(mainIntent);
						Domain_Selection.this.finish();
					}
		/*			else
					{
						Intent mainIntent = new Intent(Domain_Selection.this, Layer_Selection_Show.class);
						startActivity(mainIntent);
						Domain_Selection.this.finish();
					}*/
					//System.out.println("SCHOOL");
					//propertySelected = false;
					
					
					 /* PRISTART create first dbhelper object to call oncreate method to generate Master_table
					 */
					
					//dbHelper.insertintoMasterTable("abc");
					
					
				}
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0)
			{

			}
		});
		
		
		Button buttonLogin = (Button)findViewById(R.id.back);
		buttonLogin.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
		Intent mainIntent = new Intent(Domain_Selection.this, LoginActivity.class);
		//mainIntent.putExtra(DatabaseHelper.SURVEYOR_ID[0], 2);
		/*mainIntent.putExtra("attributeList", attributeList);
		mainIntent.putExtra("objectName", object_Name);*/
		startActivity(mainIntent);
		Domain_Selection.this.finish();
            } // end onClick
        }); // end setOnClickListen
	}	
}
